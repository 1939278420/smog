const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
    transpileDependencies: true,
    lintOnSave: false,
    publicPath: './',
    devServer: {
        proxy: {
            "/api": {
                // target: "https://www.cyberangel.xyz/",
                // ws: true,
                changeOrigin: true,
                secure: false,
                target: "http://www.honkai.store/",
                pathRewrite: {
                    '^/api': '/'
                }
            }
        }
    },
    // configureWebpack: {
    //     devServer: {
    //         historyApiFallback: true
    //     }
    // }
})