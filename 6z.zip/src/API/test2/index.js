import request from "../request";
import qs from 'qs';
export const getNews = (num) => {
    return request({
        url: "/pageNews/?id=" + num + "&i=1",
        method: 'GET'
    })
}
export const getNewsCount = () => {
    return request({
        url: "/pageNews/?i=2",
        method: 'GET'
    })
}