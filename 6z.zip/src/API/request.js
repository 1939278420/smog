import axios from "axios";
import nprogress from "nprogress";
import 'nprogress/nprogress.css'
import { Loading } from 'element-ui';
import './index.css'
// import { Toast } from "vant";
import store from "@/store";
if (process.env.NODE_ENV === "development") {
    var urls = "/api"
} else {
    var urls = "http://www.honkai.store/"
}
const request = axios.create({
    baseURL: urls,
    timeout: 15000,
})
let loadingInstance = '';
request.interceptors.request.use(config => {
    // Toast.loading("加载中...")
    loadingInstance = Loading.service({ fullscreen: true, text: "努力加载中...", customClass: "text" });
    nprogress.start()
        // Do something before request is sent
    return config;
}, error => {
    return Promise.reject(error);
});
request.interceptors.response.use(response => {
    nprogress.done()
    loadingInstance.close();
    // Toast.success("加载完毕")
    return response.data;
}, error => {
    return Promise.reject(error);
});
export default request