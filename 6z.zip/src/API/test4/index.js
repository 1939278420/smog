import request from "../request";
import qs from 'qs';
export const getNewpix = () => {
    return request({
        url: "/pixbox/?i=1&color=" + '' + '&pid=' + '',
        method: 'GET'
    })
}
export const setpix = (color, pid) => {
    return request({
        url: "/pixbox/?i=2&color=" + color + '&pid=' + pid + "",
        method: 'GET'
    })
}