import * as test1 from './test1'
import * as test2 from './test2'
import * as test3 from './test3'
import * as test4 from './test4'

export default {
    test1,
    test2,
    test3,
    test4
}