import request from "../request";
import qs from 'qs';
export const getNews = (num) => {
    return request({
        url: "/pageTags/?id=" + num + "&i=1",
        method: 'GET'
    })
}
export const getCountTags = () => {
    return request({
        url: "/pageTags/?i=2",
        method: 'GET'
    })
}
export const getAllTag = () => {
    return request({
        url: "/pageTags/?i=3",
        method: 'GET'
    })
}
export const setNewTag = (title, content, icon) => {
    return request({
        url: "/pageTags/?i=4&title=" + title + "&content=" + content + "&icon=" + icon,
        method: 'GET'
    })
}