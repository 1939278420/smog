import request from "../request";
import qs from 'qs';
export const setlooks = () => {
    const data = {
        "i": 2
    };
    return request({
        url: "/userlook/",
        method: 'POST',
        data: qs.stringify(data)
    })
}
export const getlooks = () => {
    return request({
        url: "/userlook/?i=1",
        method: 'GET',
    })
}