import final from '../child/final'
import top from '../child/top'
export default {
    components: { final, top },
    data() {
        return {

        }
    },
    methods: {

    },
}