import html2canvas from 'html2canvas';
export default {
    data() {
        return {
            permission: {
                name: "名字",
                age: "年龄",
                sex: "性别",
                xueli: "学历",
                hobby: "爱好",
                switchv: "冤种",
                datev: "日期",
                usericon: "",
                ratev: "星级",
                color: "颜色",
                tag: "tag",
            }
        }
    },
    watch: {
        "$store.state.permission" (value) {
            this.permission = value
        }
    },
    methods: {
        canvasDiv() {
            html2canvas(this.$refs.can, {
                useCORS: true, // 当图片是链接地址时，需加该属性，否组无法显示图片
                "imageTimeout": 0,
                'scale': 2
            }).then(function(canvas) {
                var MIME_TYPE = "image/png";
                var imgURL = canvas.toDataURL(MIME_TYPE);

                var dlLink = document.createElement('a');
                dlLink.download = "a"
                dlLink.href = imgURL;
                dlLink.dataset.downloadurl = [MIME_TYPE, dlLink.download, dlLink.href].join(':');

                document.body.appendChild(dlLink);
                dlLink.click();
                document.body.removeChild(dlLink);
                count = count + 1
            });
        }
    },
}