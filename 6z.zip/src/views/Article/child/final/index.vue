<template>
  <div class="pos">
    <div
    ref="can"
      class="boxpos"
    >
      <div
        class="usericon"
        :style="{
          background: 'url(' + permission.usericon + ')',
          'background-size': 'cover',
          'background-position': 'center center',
          'background-repeat': ' no-repeat',
        }"
      ></div>
      <div class="back"></div>
      <div class="back di"></div>
      <div class="info">
        <div>{{ permission.name }}</div>
        <div>{{ permission.age }}岁</div>
        <div>
          <div v-if="permission.sex">
            <i class="el-icon-male"></i>
          </div>
          <div v-else>
            <i class="el-icon-female"></i>
          </div>
        </div>
      </div>
      <div class="xueli">
        <div>{{ permission.xueli }}</div>
        <div><span class="el-icon-time"></span> {{ permission.datev }}</div>
      </div>
      <ul class="hobby">
        <li>爱好是:{{ permission.hobby }}</li>
        <li v-if="permission.switchv">大冤种</li>
        <li v-else>冤种</li>
        <li>对自己的评分居然是：{{ permission.ratev }} 分！</li>
      </ul>
      <ul class="colors">
        <li>喜欢的颜色是:{{ permission.color }}</li>
        <li>{{ permission.tag }}</li>
      </ul>
      <!-- <div>
        <div>{{ name }}</div>
        <div>{{ age }}</div>
        <div>{{ sex }}</div>
        <div>{{ xueli }}</div>
        <div>{{ hobby }}</div>
        <div>{{ switchv }}</div>
        <div>{{ datev}}</div>
        <div>{{ usericon }}</div>
        <div>{{ ratev }}</div>
        <div>{{ color }}</div>
        <div>{{ tag }}</div>
      </div> -->
    </div>
    <el-button type="primary" size="default" class="pribtn" @click="canvasDiv">生成图片</el-button>
  </div>
</template>
<script>
import index from "./js/index";
export default index;
</script>
<style src='./css/index.css' scoped>
</style>