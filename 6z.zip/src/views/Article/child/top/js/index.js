const cityOptions = ['美国', '校队', '练习时长', '两年半'];
export default {
    data() {
        return {
            input: "",
            radio: "1",
            name: '',
            age: '',
            switchv: false,
            dialogImageUrl: '',
            dialogVisible: false,
            disabled: false,
            options: [{
                value: '选项1',
                label: '黄金糕'
            }, {
                value: '选项2',
                label: '双皮奶'
            }, {
                value: '选项3',
                label: '蚵仔煎'
            }, {
                value: '选项4',
                label: '龙须面'
            }, {
                value: '选项5',
                label: '北京烤鸭'
            }],
            value: '',
            hobbyvalue: [],
            hobbyoptions: [{
                value: '游戏',
                label: '游戏',
                children: [{
                    value: '网络游戏',
                    label: '网络游戏',
                    children: [{
                        value: '英雄联盟',
                        label: '英雄联盟'
                    }, {
                        value: 'CF',
                        label: 'CF'
                    }, {
                        value: '吃鸡',
                        label: '吃鸡'
                    }, {
                        value: '永劫无间',
                        label: '永劫无间'
                    }]
                }, {
                    value: '手机游戏',
                    label: '手机游戏',
                    children: [{
                        value: '明日方舟',
                        label: '明日方舟'
                    }, {
                        value: '崩坏三',
                        label: '崩坏三'
                    }, {
                        value: '原神',
                        label: '原神'
                    }]
                }]
            }, {
                value: '运动',
                label: '运动',
                children: [{
                    value: '唱歌',
                    label: '唱歌',
                }, {
                    value: '篮球',
                    label: '篮球',
                }, {
                    value: 'rap',
                    label: 'rap',
                }]
            }, {
                value: '爱好',
                label: '爱好',
                children: [{
                    value: '更多爱好',
                    label: '更多爱好'
                }]
            }],
            datev: '',
            ratev: null,
            colors: ['#99A9BF', '#F7BA2A', '#FF9900'],
            color: '#649',
            checkAll: false,
            checkedCities: ['练习时长', '两年半'],
            cities: cityOptions,
            isIndeterminate: true,
            usericon: '',
            sex: '',
            tag: '',
            xueli: '',
            hobby: ''
        };
    },
    mounted() {
        this.$store.commit('setpages', 3)
    },
    methods: {
        handleCheckAllChange(val) {
            this.checkedCities = val ? cityOptions : [];
            this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
            let checkedCount = value.length;
            this.checkAll = checkedCount === this.cities.length;
            this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        handleRemove(file) {
            this.$refs.upload.clearFiles();
        },
        handlePictureCardPreview(file) {
            this.dialogImageUrl = file.url;
            this.dialogVisible = true;
        },
        selectIcon(file) {
            this.usericon = file.url
            this.$message({ message: '已选择', type: 'success' });
            // console.log(this.usericon);
        },
        tijiao() {
            if (this.radio == 1) {
                this.sex = true
            } else {
                this.sex = false
            }
            this.options.forEach((v, i) => {
                // console.log(v.value);
                if (v.value == this.value) {
                    this.xueli = this.options[i].label
                }
            })
            this.tag = ""
            this.checkedCities.forEach((v, i) => {
                this.tag = this.tag + v
            })
            this.hobbyvalue.forEach((v, i) => {
                if (i == this.hobbyvalue.length - 1) {
                    this.hobby = v
                }
            })
            if (this.usericon == "undefined") {
                this.$message({ message: '头像确认后再提交哦~', type: 'warning' });
            }
            if (this.name != "" && this.age != "" && this.xueli != '' && this.hobby != '' && this.datev != '' && this.ratev != '') {
                console.log("名字:" + this.name + ",年龄:" + this.age + ",性别:" + this.sex + ",学历:" + this.xueli + ",爱好:" + this.hobby + ",大冤种:" + this.switchv + ",生日:" + this.datev + ",头像:" + this.usericon + ",打分:" + this.ratev + ",幸运色:" + this.color + ",Tag:" + this.tag);
                this.$store.commit('setpermission', {
                    name: this.name,
                    age: this.age,
                    sex: this.sex,
                    xueli: this.xueli,
                    hobby: this.hobby,
                    switchv: this.switchv,
                    datev: this.datev,
                    usericon: this.usericon,
                    ratev: this.ratev,
                    color: this.color,
                    tag: this.tag
                })
            } else {
                this.$message({ message: "检查一下哪里没写满哦！", type: 'warning' })
            }
        }
    }
}