<template>
  <div>
    <div class="pos">
      <ul>
        <li class="tag">
          <div>姓名:</div>
          <el-input
            class="ipt"
            v-model="name"
            placeholder="请输入名字"
            maxlength="5"
          ></el-input>
        </li>
        <li class="tag">
          <el-radio v-model="radio" label="1">男</el-radio>
          <el-radio v-model="radio" label="2">女</el-radio>
        </li>
        <li class="tag">
          <div>年龄:</div>
          <el-input
            class="ipt"
            v-model="age"
            placeholder="请输入年龄"
            maxlength="3"
            type="number"
          ></el-input>
        </li>
        <li class="tag">
          <div>学历:</div>
          <el-select v-model="value" placeholder="请选择" clearable filterable>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </li>
        <li class="block tag">
          <span class="demonstration">选择爱好:</span>
          <el-cascader
            v-model="hobbyvalue"
            :options="hobbyoptions"
            :props="{ expandTrigger: 'hover' }"
          ></el-cascader>
        </li>
        <li class="tag">
          <span>你是大冤种么？:&nbsp;</span>
          <el-switch
            v-model="switchv"
            active-text="是"
            inactive-text="我想我是"
          >
          </el-switch>
        </li>
      </ul>
      <ul>
        <li class="block tag">
          <span class="demonstration">选择你的生日:&nbsp;</span>
          <el-date-picker
            v-model="datev"
            type="date"
            format="yyyy 年 M 月 d 日"
            value-format="yyyy-MM-dd"
            placeholder="选择日期"
          >
          </el-date-picker>
        </li>
        <li class="block tag">
          <span class="demonstration">给自己打分:&nbsp;</span>
          <el-rate v-model="ratev" :colors="colors"> </el-rate>
        </li>
        <li class="block tag">
          <span class="demonstration">选择幸运色:&nbsp;</span>
          <el-color-picker v-model="color"></el-color-picker>
        </li>
        <li class="block tag">
          <span class="demonstration">选择Tag:&nbsp;</span>
          <el-checkbox
            :indeterminate="isIndeterminate"
            v-model="checkAll"
            @change="handleCheckAllChange"
            >全选</el-checkbox
          >
          <div style="margin: 15px 0"></div>
          <el-checkbox-group
            v-model="checkedCities"
            @change="handleCheckedCitiesChange"
            class="checkbox"
          >
            <el-checkbox v-for="city in cities" :label="city" :key="city">{{
              city
            }}</el-checkbox>
          </el-checkbox-group>
        </li>
        <li class="block tag uploadImg">
          <div class="demonstration"
            >选择你的头像<br />(上传后需要移到图片上点击确认):&nbsp;</div
          >
          <el-upload
            action="#"
            ref="upload"
            list-type="picture-card"
            :auto-upload="false"
            :limit="1"
            class="upimg"
          >
            <i slot="default" class="el-icon-plus"></i>
            <div slot="file" slot-scope="{ file }">
              <img
                class="el-upload-list__item-thumbnail"
                :src="file.url"
                alt=""
              />
              <span class="el-upload-list__item-actions">
                <span
                  class="el-upload-list__item-preview"
                  @click="handlePictureCardPreview(file)"
                >
                  <i class="el-icon-zoom-in"></i>
                </span>
                <span
                  v-if="!disabled"
                  class="el-upload-list__item-delete"
                  @click="selectIcon(file)"
                >
                  <i class="el-icon-check"></i>
                </span>
                <span
                  v-if="!disabled"
                  class="el-upload-list__item-delete"
                  @click="handleRemove(file)"
                >
                  <i class="el-icon-delete"></i>
                </span>
              </span>
            </div>
          </el-upload>
          <el-dialog :visible.sync="dialogVisible">
            <img width="100%" :src="dialogImageUrl" alt="" />
          </el-dialog>
        </li>
      </ul>
    </div>
    <el-button class="btn" type="primary" size="default" @click="tijiao"
      >提交</el-button
    >
  </div>
</template>
<script>
import index from "./js/index";
export default index;
</script>
<style src='./css/index.css' scoped>
</style>