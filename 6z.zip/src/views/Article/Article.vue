<template>
  <div class="about">
    <div class="from">
      <top/>
    </div>
    <div class="final">
      <final/>
    </div>
  </div>
</template>
<script>
import index from "./js";
export default index;
</script>
<style src="./css/index.css" scoped>
</style>