<template>
  <div>
    <menus class="top" />
    <router-view></router-view>
    <!-- <test3/> -->
  </div>
</template>

<script>
// @ is an alias to /src
import test3 from "@/components/page1/test3/";
import menus from "@/components/el-menu/index.vue";
export default {
  name: "HomeView",
  components: {
    menus,
    test3,
  },
};
</script>
<style scoped>
/* .top {
  margin-bottom: 50px;
} */
h2 {
  margin-top: 100px;
}
</style>
