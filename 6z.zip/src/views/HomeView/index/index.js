import test1 from "@/components/page1/test1/test1.vue";
import test2 from "@/components/page1/test2/";
import test4 from "@/components/page1/test4/";
import test5 from "@/components/page1/test5/";
import test6 from "@/components/page1/test6/";
import test7 from "@/components/page1/test7/";
import test8 from "@/components/page1/test8/";
import test9 from "@/components/page1/test9/";
import test10 from "@/components/page1/test10/";
import test11 from "@/components/page1/test11/";
import test12 from "@/components/page1/test12/";
import test13 from "@/components/page1/test13/";
export default {
    data() {
        return {
            t6flag: false,
            t2flag: false,
            cposflag: false,
            looks: 0,
            musicflag: false
        };
    },
    mounted() {
        this.getAPI()
        var that = this
        document.addEventListener('scroll', function() {
            // document.documentElement.scrollTop += 200
            if (document.documentElement.scrollTop > 900) {
                that.t6flag = true
            } else {
                that.t6flag = false
            }
            if (document.documentElement.scrollTop > 400) {
                that.t2flag = true
            } else {
                that.t2flag = false
            }
        })
    },
    methods: {
        changeTheme() {
            this.$router.push('/theme')
        },
        async getAPI() {
            const res = await this.$API.test1.getlooks();
            this.looks = res;
            const sres = await this.$API.test1.setlooks();
        },
        linkPix(pushlj) {
            this.$router.push(pushlj)
        }
    },
    components: {
        test1,
        test2,
        test4,
        test5,
        test6,
        test7,
        test8,
        test9,
        test10,
        test11,
        test12,
        test13
    },
};