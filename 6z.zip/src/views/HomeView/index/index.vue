<template>
  <div>
    <div class="main">
      <h4>Ip:Cyberangel.xyz</h4>
      <h4>Ip:honkai.store</h4>
      <h4>Active:True</h4>
      <h4>Live:Undefined</h4>
      <h4>UserActive:Null</h4>
      <h4>Tips:Welcome to my page！！</h4>
    </div>
    <div id="fix">
      <test9 />
      <test10 v-if="musicflag"/>
      <test13/>
      <!-- <div class="xsdz" @click="linkPix('/pix')" id="mouseH">
        像素大战
      </div>
      <div class="xsdz" @click="linkPix('/genshin')" id="mouseH" style="top:400px !important;" :style="{'background':'url(https://s1.ax1x.com/2022/12/14/zIajjx.jpg)','background-size':'100% 100%'}">
        原神抽卡
      </div> -->
    </div>
    <test12/>
    <div class="back">
      <div class="change-music" id="mouseH" @click="musicflag=!musicflag">MUSIC&nbsp;&nbsp;></div>
      <div class="change-theme" id="mouseH" @click="changeTheme()">切换主题&nbsp;&nbsp;></div>
      <test4 class="t4" />
      <div class="cPos"><test5 class="" /><test8 /></div>
      <test1 class="t1" />
      <test2 class="t2"/>
      <test7/>
      <test6 v-show="t6flag" />
    </div>
    <h2>本站浏览数:{{ looks }}</h2>
  </div>
</template>
<script>
import index from "./index.js";
export default index;
</script>
<style src='./css/index.css' scoped>
</style>
