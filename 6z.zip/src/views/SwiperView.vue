<template>
  <div
    class="swiper-container swi"
    :style="{'height':hei+'px','width':wid+'px'}"
  >
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <test2 />
      </div>
      <div class="swiper-slide">
        <test1 />
      </div>
      <div class="swiper-slide">
        <test4 />
      </div>
      <div class="swiper-slide">
        <test3 />
      </div>
    </div>
    <div class="swiper-pagination dottag"></div>
  </div>
</template>
<script>
import test1 from "@/components/page2/test1/";
import test2 from "@/components/page2/test2/";
import test3 from "@/components/page2/test3/";
import test4 from "@/components/page2/test4/";

import Swiper from "swiper";
export default {
  components: {
    test1,
    test2,
    test3,
    test4
  },
  data() {
    return {
      hei: 936,
      wid:1920,
    };
  },
  mounted() {
    let that = this;
    var myswiper = new Swiper(".swi", {
      // autoplay:{
      //   delay:3000,
      //   disableOnInteraction: false,
      // },
      allowTouchMove: false,
      parallax: true,
      speed: 600,
      // loop: true,
      direction: "vertical",
      touchRatio: 0.5,
      pagination: {
        el: ".dottag",
        clickable: true,
      },
      mousewheel: true,
      on: {
        init: function (swiper) {
          // console.log(this.activeIndex);
          that.$store.commit('setflag',this.activeIndex)
          // this.slideTo(2, 100, false);
        },
        slideChangeTransitionStart: function () {
          // console.log(this.activeIndex); //切换结束时，告诉我现在是第几个slide
          that.$store.commit('setflag',this.activeIndex)
        },
      },
      // effect:'cube'
    });
    this.hei = window.innerHeight;
    this.wid = window.innerWidth;
    window.onresize = function () {
      that.hei = window.innerHeight;
      that.wid = window.innerWidth;
    };

  },
};
</script>
<style lang="less" scoped>
.swi {
  width: 100%;
  min-width: 100%;
  // height: 937px;
  // background-image: url(../../../public/images/disco.png);
  // background-size: cover;
  // background-color: rgb(202, 173, 247);
}
.swiper-slide {
  width: 100%;
  user-select: none;
}
::v-deep .swiper-pagination-bullet {
  cursor: url("../static/images/cursor-inner.1d69419cb78ed4579ad9.png") 3 3,
    default;
  width: 5px;
  height: 30px;
  border-radius: 0px;
  background-color: rgb(255, 255, 255) !important;
}
/deep/ .swiper-pagination-bullet-active {
  width: 5px;
  height: 30px;
  border-radius: 0px;
  background-color: rgb(238, 255, 0) !important;
}
</style>
