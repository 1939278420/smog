<template>
  <div id="app">
    <cursors />
    <router-view />
    <backtop />
  </div>
</template>
<script>
import cursors from "./components/cursor/index.vue";
import menus from "./components/el-menu/index.vue";
import backtop from "./components/backtop/index.vue";
import $ from "jquery";
export default {
  components: {
    cursors,
    menus,
    backtop,
  },
  data() {
    return {
      seibg: 1,
    };
  },
  created() {
    if (!this.IsPC()) {
      location.href = "http://honkai.store/phone";
    }
    this.infine();
    $("body").addClass("defaultBack");
  },
  mounted() {
    this.seibg = localStorage.getItem("themebg");
    if (!isNaN(this.seibg)) {
      let num = parseInt(this.seibg);
      switch (num) {
        case 1:
          $("body").addClass("defaultBack");
          break;
        case 2:
          $("body").removeClass('defaultBack');
          $("body").addClass("bg2");
          break;
        case 3:
          $("body").removeClass('defaultBack');
          $("body").addClass("bg3");
          break;
        case 4:
          $("body").removeClass('defaultBack');
          $("body").addClass("bg4");
          break;
        case 5:
          $("body").removeClass('defaultBack');
          $("body").addClass("bg5");
          break;   
        case 6:
          $("body").removeClass('defaultBack');
          $("body").addClass("bg6");
          break;    
        case 7:
          $("body").removeClass('defaultBack');
          $("body").addClass("bg1");
          break;  
      }
    }
  },
  updated() {
    this.seibg = localStorage.getItem("themebg");
  },
  methods: {
    infine() {
      var hiddenProperty =
        "hidden" in document
          ? "hidden"
          : "webkitHidden" in document
          ? "webkitHidden"
          : "mozHidden" in document
          ? "mozHidden"
          : null;
      var timer;
      document.addEventListener(
        hiddenProperty.replace(/hidden/i, "visibilitychange"),
        function () {
          if (!document[hiddenProperty]) {
            document.title = "回到页面啦！";
            timer = setTimeout(() => {
              document.title = "虚数空间";
            }, 1000);
          } else {
            clearTimeout(timer);
            document.title = "真的不在驻足看看嘛？";
          }
        }
      );
    },
    IsPC() {
      var userAgentInfo = navigator.userAgent;
      var Agents = [
        "Android",
        "iPhone",
        "SymbianOS",
        "Windows Phone",
        "iPad",
        "iPod",
      ];
      var flag = true;
      for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
          flag = false;
          break;
        }
      }
      return flag;
    },
  },
};
</script>
<style lang="less">
.swiper-pagination-bullet {
  background: rgb(255, 255, 255) !important;
  opacity: 1 !important;
}
</style>
<style lang="less">
.text {
  color: #649 !important;
}
.bread {
  background-color: #fff;
}
.tolink {
  width: 100%;
  height: 100%;
  display: block;
  text-decoration: none;
}
</style>
<style lang="less">
* {
  margin: 0;
  padding: 0;
}
#app {
  overflow-x: hidden;
  cursor: url("./static/images/cursor-inner.1d69419cb78ed4579ad9.png") 3 3,
    default;
}
body{
  background: url(https://s1.ax1x.com/2022/10/27/xf1rCV.jpg);
}
.defaultBack{
  background: url("../public/img/back-defalut.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
.bg1 {
  background: url(https://s1.ax1x.com/2022/10/27/xf1rCV.jpg);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
.bg2 {
  background: url("../public/img/ui设计 拷贝.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
.bg3 {
  background: url(https://s1.ax1x.com/2022/10/27/xfUKYj.png);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
.bg4 {
  background: url(https://s1.ax1x.com/2022/10/27/xfceFP.png);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
.bg5 {
  background: url(https://s1.ax1x.com/2022/10/27/xfgZnJ.png);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
.bg6 {
  background: url(https://s1.ax1x.com/2022/11/25/zYwfJO.jpg);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow-x: hidden;
}
body {
  cursor: url("./static/images/cursor-inner.1d69419cb78ed4579ad9.png") 3 3,
    default;
  user-select: none;
  // cursor: url(https://zhutix.com/wp-content/themes/b2/x1.cur), auto;
  // background: url("../public/img/ui设计 拷贝.png");
  // background: url("../public/img/s1.jpg");
  // background: url(https://s1.ax1x.com/2022/10/27/xf1rCV.jpg);
}
::-webkit-scrollbar {
  width: 7px;
}
/* 滚动槽 */
::-webkit-scrollbar-track {
  // -webkit-box-shadow:inset006pxrgba(0,0,0,0.3);
  border-radius: 10px;
  background-color: rgba(197, 197, 197, 0.199);
}
/* 滚动条滑块 */
::-webkit-scrollbar-thumb {
  border-radius: 10px;
  background: rgba(0, 0, 0, 0.24);
  // -webkit-box-shadow:inset006pxrgba(0,0,0,0.5);
}
::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(0, 0, 0, 0.158);
}
</style>
