import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        pages: 1,
        flag: 999,
        permission: {
            name: "名字",
            age: "年龄",
            sex: "性别",
            xueli: "学历",
            hobby: "爱好",
            switchv: "冤种",
            datev: "日期",
            usericon: "头像",
            ratev: "星级",
            color: "颜色",
            tag: "tag",
        },
        menuflagbtn: true
    },
    getters: {},
    mutations: {
        setflagbtn(state, data) {
            state.menuflagbtn = data
        },
        setflag(state, data) {
            state.flag = data
        },
        setpages(state, data) {
            state.pages = data
        },
        setpermission(state, data) {
            state.permission = data
        }
    },
    actions: {},
    modules: {},
});