<template>
  <div>
    <div class="mousemove" ref="sdd" :class="{ selectBox: flag }" id="mm"></div>
    <div class="cycBox" ref="sde">
      <div class="mouseclick" ref="sdec"></div>
    </div>
  </div>
</template>
<script>
/* mouseH是id标识，使其充分利用，标识者会添加事件 */
import $ from "jquery";
import router from "../../router/index";
export default {
  data() {
    return {
      flag: false,
      timer: "",
      oEvent: "",
    };
  },
  destroyed() {
    $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
    $("#mm").css({ border: "3px solid #9E9E9E" });
    $("#app").removeClass("cursorpoint");
  },
  mounted() {
    var that = this;
    document.onclick = function (evt) {
      clearTimeout(this.timer);
      that.$refs.sdec.style.display = "none";
      that.flag = true;
      that.$nextTick(function () {
        var oEvent = evt || window.event;
        that.$refs.sde.style.left = oEvent.clientX - 50 + "px";
        that.$refs.sde.style.top = oEvent.clientY - 50 + "px";
        that.$refs.sdec.style.display = "block";
        this.timer = setTimeout(() => {
          that.$refs.sdec.style.display = "none";
          that.flag = false;
        }, 400);
      });
    };
    document.addEventListener("scroll", function () {
      setTimeout(() => {
        var s = document.documentElement.scrollTop || document.body.scrollTop;
        that.$refs.sdd.style.left = that.oEvent.clientX - 0 + "px";
        that.$refs.sdd.style.top = that.oEvent.clientY + s - 0 + "px";
        that.$refs.sdd.style.display = "block";
      }, 10);
    });
    document.onmousemove = function (evt) {
      var oEvent = evt || window.event;
      that.oEvent = evt || window.event;
      setTimeout(() => {
        var s = document.documentElement.scrollTop || document.body.scrollTop;
        that.$refs.sdd.style.left = oEvent.clientX - 0 + "px";
        that.$refs.sdd.style.top = oEvent.clientY + s - 0 + "px";
        that.$refs.sdd.style.display = "block";
      }, 50);
    };
    router.beforeEach((to, from, next) => {
      // console.log(to, from);
      $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
      $("#mm").css({ border: "3px solid #9E9E9E" });
      $("#app").removeClass("cursorpoint");
      next();
    });
    $("body").delegate("div#mouseH", "mouseenter", function () {
      $("#mm").stop().animate({ height: "20px", width: "20px" }, 500);
      $("#mm").css({ border: "3px solid #d3d3d385" });
      $("#app").addClass("cursorpoint");
    });
    $("body").delegate("div#mouseH", "mouseleave", function () {
      $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
      $("#mm").css({ border: "3px solid #9E9E9E" });
      $("#app").removeClass("cursorpoint");
    });
    $("body").delegate("ul>li#mouseH", "mouseenter", function () {
      $("#mm").stop().animate({ height: "20px", width: "20px" }, 500);
      $("#mm").css({ border: "3px solid #d3d3d385" });
      $("#app").addClass("cursorpoint");
    });
    $("body").delegate("ul>li#mouseH", "mouseleave", function () {
      $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
      $("#mm").css({ border: "3px solid #9E9E9E" });
      $("#app").removeClass("cursorpoint");
    });
    $("body").delegate("ul>ol#mouseH", "mouseenter", function () {
      $("#mm").stop().animate({ height: "20px", width: "20px" }, 500);
      $("#mm").css({ border: "3px solid #d3d3d385" });
      $("#app").addClass("cursorpoint");
    });
    $("body").delegate("ul>ol#mouseH", "mouseleave", function () {
      $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
      $("#mm").css({ border: "3px solid #9E9E9E" });
      $("#app").removeClass("cursorpoint");
    });
     $("body").delegate("button#mouseH", "mouseenter", function () {
      $("#mm").stop().animate({ height: "20px", width: "20px" }, 500);
      $("#mm").css({ border: "3px solid #d3d3d385" });
      $("#app").addClass("cursorpoint");
    });
    $("body").delegate("button#mouseH", "mouseleave", function () {
      $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
      $("#mm").css({ border: "3px solid #9E9E9E" });
      $("#app").removeClass("cursorpoint");
    });
    $("body").delegate("span#mouseH", "mouseenter", function () {
      $("#mm").stop().animate({ height: "20px", width: "20px" }, 500);
      $("#mm").css({ border: "3px solid #d3d3d385" });
      $("#app").addClass("cursorpoint");
    });
    $("body").delegate("span#mouseH", "mouseleave", function () {
      $("#mm").stop().animate({ height: "30px", width: "30px" }, 200);
      $("#mm").css({ border: "3px solid #9E9E9E" });
      $("#app").removeClass("cursorpoint");
    });
  },
};
</script>
<style>
.cursorpoint {
  cursor: url("../../static/images/xsdg.png") 3 3, default !important;
}
</style>
<style lang="less" scoped>
.cycBox {
  width: 100px;
  height: 100px;
  /* background-color: #fff; */
  position: fixed;
  top: 0px;
  z-index: 999;
  left: 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  align-content: center;
  pointer-events: none;
}
.mouseclick {
  pointer-events: none;
  width: 0px;
  height: 0px;
  display: none;
  border: 2px solid #c4c3c3;
  border-radius: 50%;
  z-index: 999;
  animation: cycleBig 0.3s ease-in-out forwards;
}
@keyframes cycleBig {
  0% {
    opacity: 0;
    width: 0px;
    height: 0px;
  }
  30% {
    opacity: 1;
  }
  100% {
    width: 80px;
    height: 80px;
    opacity: 0;
  }
}
.selectBox {
  transition: 0.3s linear;
  background-color: rgba(255, 255, 255, 0.055);
}
.mousemove {
  position: absolute;
  width: 30px;
  height: 30px;
  top: 20px;
  left: 0px;
  z-index: 999999;
  pointer-events: none;
  border: 3px solid #9e9e9e;
  border-radius: 50%;
  display: none;
  transform: translate(-50%, -50%);
}
</style>