<template>
  <div class="page">
    <!-- <div>{{list.id}}</div> -->
    <test11 title="标题" :num="'0'+this.$route.query.num"/>
    <div>
      <div>{{ list.c1 }}</div>
      <div>{{ list.c2 }}</div>
    </div>
    <div>
      <div>{{ list.c3 }}</div>
      <div>{{ list.c4 }}</div>
    </div>
  </div>
</template>
<script>
import index from "./js/index.js";
export default index;
</script>
<style src="./css/index.css" scoped>
</style>