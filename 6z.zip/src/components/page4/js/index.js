import axios from "axios"
import test11 from "@/components/page1/test11/";
export default {
    data() {
        return {
            list: []
        }
    },
    mounted() {
        this.getAPI()
    },
    methods: {
        async getAPI() {
            const res = await this.$API.test2.getNews(this.$route.query.num)
            this.list = res[0]
        }
    },
    destroyed() {
        this.$store.commit("setflagbtn", true);
    },
    components: {
        test11
    },
}