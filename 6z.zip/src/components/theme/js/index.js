import $ from 'jquery'
import ElementUI from 'element-ui';
import { number } from 'echarts';
export default {
    name: "theme",
    data() {
        return {
            bagimgList: ["url('./img/back-defalut.png')", "url(https://s1.ax1x.com/2022/10/27/xfUmTg.png)", "url(https://s1.ax1x.com/2022/10/27/xfUKYj.png)", "url(https://s1.ax1x.com/2022/10/27/xfceFP.png)", "url(https://s1.ax1x.com/2022/10/27/xfgZnJ.png)", 'url(https://s1.ax1x.com/2022/11/25/zYwfJO.jpg)', 'url(https://s1.ax1x.com/2022/10/27/xf1rCV.jpg)'],
            banums: 0,
            flag: true
        };
    },
    mounted() {
        this.$store.commit("setflagbtn", false)
        let hei = window.innerHeight
        $("#theme").css('height', (hei) + 'px')
        let sei = localStorage.getItem("themebg");
        // if (!isNaN(sei)) {
        //     this.banums = parseInt(sei) - 1
        // } else {
        //     this.banums = 0
        // }
        document.documentElement.scrollTop = 0
        setTimeout(() => {
            let i = 0;
            let timer = setInterval(() => {
                if (i < 60) {
                    i++
                } else {
                    clearInterval(timer)
                }
                document.documentElement.scrollTop = i
            }, 5);
        }, 500);
    },
    destroyed() {
        this.$store.commit("setflagbtn", true);
    },
    methods: {
        btnchanges(num) {
            this.banums = parseInt(num) - 1
        },
        bgchange(num) {
            if (this.flag) {
                this.$message('已设置背景，点击刷新后应用');
                localStorage.clear('themebg')
                localStorage.setItem("themebg", (this.banums + 1));
                this.flag = false
                setTimeout(() => {
                    this.flag = true
                }, 3000);
            } else {
                this.$message('冷却中');
            }
        },
        remain() {
            this.$router.push('/')
        },
        reflush() {
            location.reload()
        }
    }
}