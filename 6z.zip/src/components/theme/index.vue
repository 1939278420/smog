<template>
  <div class="pos" id="theme">
    <div class="cebian">
      <ul v-for="(item, index) in bagimgList" :key="index">
        <li @click="btnchanges(index + 1)" class="btn"  id="mouseH" :class="{'sbtn':banums==index}">背景{{ index + 1 }}</li>
      </ul>
      <div @click="bgchange()" class="flush" id="mouseH">确定</div>
      <div @click="reflush()" class="flush" id="mouseH">刷新</div>
      <div @click="remain()" class="flush" id="mouseH">返回首页</div>
    </div>
    <div class="bgimg" :style="{'background':bagimgList[banums]}">

    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>