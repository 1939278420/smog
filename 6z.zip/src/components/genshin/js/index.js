import ElementUI from 'element-ui';
// import $ from jQuery;
export default {
    data() {
        return {
            cklist: [],
            adioplay: true,
            flag: false,
            boxflag: 0,
            cka: 0,
            cancelflag: false,
            jiesuanflag: false,
            cancelflag2: false,
            shareflag: false,
            vidflag: false,
            timer: "",
            bencicknum: 0,
            upnameliu: '温蒂',
            upnamewu: '绿派蒙',
            back: 'https://s1.ax1x.com/2022/12/14/zIduVS.png',
            chizi: [
                { 'liuname': "温蒂", id: 0, 'wuname': '绿派蒙', 'dabaodi': false, 'baodi': 0, back: 'https://s1.ax1x.com/2022/12/14/zIduVS.png' },
                { 'liuname': "金派蒙", id: 1, 'wuname': '红派蒙', 'dabaodi': false, 'baodi': 0, back: 'https://s1.ax1x.com/2022/12/14/zIdUVU.jpg' },
            ],
            dangqianid: 0,
            jueselistliu: [{
                "name": '温蒂',
                "content": "./img/chouka/g1.png",
                "background": './img/chouka/c1.png',
                "star": 6
            }, {
                "name": '金派蒙',
                "content": "./img/chouka/g2.png",
                "background": './img/chouka/dd.png',
                "star": 6
            }],
            jueselistwu: [{
                "name": '绿派蒙',
                "content": "./img/chouka/c.png",
                "background": './img/chouka/bb.png',
                "star": 5
            }, {
                "name": '红派蒙',
                "content": "./img/chouka/g3.png",
                "background": './img/chouka/cc.png',
                "star": 5
            }],
            jueselistsi: [{
                "name": '派蒙',
                "content": "./img/chouka/g4.png",
                "background": './img/chouka/aa.png',
                "star": 4
            }, {
                "name": '派蒙',
                "content": "./img/chouka/g4.png",
                "background": './img/chouka/aa.png',
                "star": 4
            }],
            list: {
                "id": 1,
                "content": "https://s1.ax1x.com/2022/this.gailvwu/13/z58o40.png",
                "name": 'xxx',
                "star": 5,
                "background": 'https://s1.ax1x.com/2022/10/27/xf1rCV.jpg'
            },
            gailvliu: 2, //2
            gailvwu: 14, //14 为26%(+12)
            upgailv: 3, //6
            baodicount: 100 //100
        }
    },
    watch: {},
    created() {
        this.gailvwu = parseFloat(this.gailvliu + 12)
    },
    mounted() {
        this.$alert('完全模拟抽卡，动画些许不同', '原神抽卡', {
            confirmButtonText: '我知道了',
            callback: action => {
                this.pausePlayadio(0)
            }
        });
    },
    methods: {
        qiechizi(id) {
            this.dangqianid = id
            this.upnameliu = this.chizi[id].liuname
            this.upnamewu = this.chizi[id].wuname
            this.back = this.chizi[id].back
        },
        pausePlayadio(num) {
            var d = document.getElementById('adio');
            if (num == 1) {
                d.pause()
                this.adioplay = false
            } else {
                d.play()
                this.adioplay = true
            }
        },
        shares() {
            this.$message("暂未开放")
        },
        pausePlay() {
            this.vidflag = false
            document.getElementById('vid').currentTime = 0;
            clearTimeout(this.timer)
            document.getElementById('vid').pause()
            this.pailie(this.bencicknum, this.upnameliu)
        },
        jiesuan() {
            this.cancelflag = false
            this.jiesuanflag = true
            this.cancelflag2 = true
            this.shareflag = true
            this.boxflag = 99999
        },
        fanhui() {
            this.cklist = []
            this.flag = false
            this.boxflag = 0
            this.cancelflag = false;
            this.jiesuanflag = false;
            this.shareflag = false
            this.cancelflag2 = false
        },
        truebox() {
            if (this.boxflag < this.cka - 1) {
                this.boxflag += 1
                    // console.log(this.boxflag + "x" + this.cka);
            } else {
                // console.log('chufa');
                this.jiesuan()
            }
        },
        chouka(num) {
            this.bencicknum = num
            this.vidflag = true;
            if (this.chizi[this.dangqianid].baodi + num > this.baodicount) {
                this.chizi[this.dangqianid].baodi = this.baodicount
            } else {
                this.chizi[this.dangqianid].baodi += num
            }
            document.getElementById('vid').play();
            this.timer = setTimeout(() => {
                document.getElementById('vid').currentTime = 0;
                this.vidflag = false;
                document.getElementById('vid').pause();
                this.pailie(num)
            }, 5800);
        },
        xunhuansi() {
            let r = parseInt(this.randoms(0, this.jueselistwu.length - 1))
            if (r <= this.jueselistsi.length - 1) {
                this.list.content = this.jueselistsi[r].content
                this.list.name = this.jueselistsi[r].name
                this.list.star = this.jueselistsi[r].star
                this.list.background = this.jueselistsi[r].background
            }
        },
        xunhuanwu(j) {
            let ran = parseInt(this.randoms(0, this.jueselistwu.length - 1))
                // console.log((ran <= this.jueselistwu.length - 1) + "+" + (this.jueselistwu[j].name != this.upnamewu));
            if (this.jueselistwu[j].name != this.upnamewu && ran <= this.jueselistwu.length - 1) {
                this.list.content = this.jueselistwu[j].content
                this.list.name = this.jueselistwu[j].name
                this.list.star = this.jueselistwu[j].star
                this.list.background = this.jueselistwu[j].background
            }
        },
        xunhuanliu(j) {
            let ran = parseInt(this.randoms(0, this.jueselistwu.length - 1))
            if (this.jueselistliu[j].name != this.upnameliu && ran <= this.jueselistliu.length - 1) {
                this.list.content = this.jueselistliu[j].content
                this.list.name = this.jueselistliu[j].name
                this.list.star = this.jueselistliu[j].star
                this.list.background = this.jueselistliu[j].background
            }
        },
        randoms(min, max) {
            if (min > max) {
                var ls = min;
                min = max;
                max = ls;
            }
            return Math.floor(Math.random() * (max - min + 1)) + min;
        },
        pailie(num) {
            this.cancelflag = true
            this.cka = num
            this.flag = true
            this.shareflag = true
            for (let i = 0; i < num; i++) {
                this.list = {
                    "id": 1,
                    "content": "https://s1.ax1x.com/2022/this.gailvwu/13/z58o40.png",
                    "name": 'xxx',
                    "star": 5,
                    "background": 'https://s1.ax1x.com/2022/10/27/xf1rCV.jpg'
                }
                this.list.id = i
                var rans = (Math.random() * 100).toFixed(1)
                if (rans < 0) {
                    rans = rans * -1
                }
                if (num > 1 && i == num - 1) {
                    let numflag = false
                    for (let z in this.cklist) {
                        if (this.cklist[z].star > 4) {
                            numflag = true
                        }
                    }
                    if (!numflag) {
                        rans = parseFloat(this.gailvwu)
                    }
                    // console.log(rans + "⑩");
                }
                rans = parseFloat(rans)
                    // console.log((rans <= parseFloat(this.gailvliu)) + "=" + rans + "+" + parseFloat(this.gailvliu));
                if (this.baodicount - parseInt(this.chizi[this.dangqianid].baodi) != 0) {
                    if (rans <= parseFloat(this.gailvliu)) {
                        let r = (Math.random() * 10).toFixed(0)
                            // console.log('触发1' + "+" + rans + "+" + parseFloat(this.gailvliu) + "+" + r + "+" + this.upgailv);
                        if (r <= this.upgailv) {
                            for (let j in this.jueselistliu) {
                                if (this.jueselistliu[j].name == this.upnameliu) {
                                    this.list.content = this.jueselistliu[j].content
                                    this.list.name = this.jueselistliu[j].name
                                    this.list.star = this.jueselistliu[j].star
                                    this.list.background = this.jueselistliu[j].background
                                }
                            }
                            this.chizi[this.dangqianid].dabaodi = false
                            this.chizi[this.dangqianid].baodi = 0
                        } else {
                            for (let j in this.jueselistliu) {
                                this.xunhuanliu(j)
                            }
                            this.chizi[this.dangqianid].dabaodi = true
                        }
                    }
                    if (rans > parseFloat(this.gailvliu) && rans <= parseFloat(this.gailvwu)) {
                        // console.log('触发2');
                        let r = parseInt((Math.random() * 10))
                        if (r < this.upgailv) {
                            for (let j in this.jueselistwu) {
                                if (this.jueselistwu[j].name == this.upnamewu) {
                                    this.list.content = this.jueselistwu[j].content
                                    this.list.name = this.jueselistwu[j].name
                                    this.list.star = this.jueselistwu[j].star
                                    this.list.background = this.jueselistwu[j].background
                                }
                            }
                        } else {
                            for (let j in this.jueselistwu) {
                                this.xunhuanwu(j)
                            }
                        }
                    }
                    if (rans > parseFloat(this.gailvwu)) {
                        this.xunhuansi()
                    }
                } else {
                    if (this.chizi[this.dangqianid].dabaodi) {
                        for (let j in this.jueselistliu) {
                            if (this.jueselistliu[j].name == this.upnameliu) {
                                this.list.content = this.jueselistliu[j].content
                                this.list.name = this.jueselistliu[j].name
                                this.list.star = this.jueselistliu[j].star
                                this.list.background = this.jueselistliu[j].background
                            }
                        }
                        this.chizi[this.dangqianid].dabaodi = false
                    } else {
                        let r = (Math.random() * 10).toFixed(0)
                        if (r <= this.upgailv) {
                            for (let j in this.jueselistliu) {
                                if (this.jueselistliu[j].name == this.upnameliu) {
                                    this.list.content = this.jueselistliu[j].content
                                    this.list.name = this.jueselistliu[j].name
                                    this.list.star = this.jueselistliu[j].star
                                    this.list.background = this.jueselistliu[j].background
                                }
                            }
                            this.chizi[this.dangqianid].dabaodi = false
                        } else {
                            for (let j in this.jueselistliu) {
                                this.xunhuanliu(j)
                            }
                            this.chizi[this.dangqianid].dabaodi = true
                        }
                    }
                    this.chizi[this.dangqianid].baodi = 0
                }
                this.cklist.push(this.list)
            }
            // console.log(this.cklist);
        }
    }
}