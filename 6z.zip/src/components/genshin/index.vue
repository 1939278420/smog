<template>
  <div class="commian">
    <div class="chizi">
      <div id="mouseH" class="chizitag" v-for="(v,i) in chizi" :key="i" :class="{'selects':dangqianid==i}" @click="qiechizi(v.id)">{{v.liuname}}</div>
    </div>
    <div class="page">
      <div
        type="primary"
        size="default"
        @click="pausePlayadio(1)"
        id="mouseH"
        class="bgm"
        v-if="adioplay"
      >
        关闭BGM
      </div>
      <div
        type="primary"
        size="default"
        @click="pausePlayadio(0)"
        id="mouseH"
        class="bgm"
        v-else
      >
        开启BGM
      </div>
      <audio loop id="adio" autoplay muted>
        <source src="../../../public/video/aes.mp3" type="audio/ogg" />
        您的浏览器不支持 audio 元素。
      </audio>
      <div class="back" :style="{'background':'url('+back+')','background-size':'100% 100%'}"></div>
      <video
        muted
        autoplay="autoplay"
        loop="loop"
        class="backgrous"
        v-show="!vidflag"
      >
        <source src="../../../public/video/es.mp4" type="video/mp4" />
        您的浏览器不支持Video标签。
      </video>
      <div class="dabd" v-if="!chizi[dangqianid].dabaodi">小保底</div>
      <div class="dabd" v-else>大保底</div>
      <div class="baodi" v-if="baodicount - chizi[dangqianid].baodi - 1 > 0">
        剩余保底次数:{{ baodicount - chizi[dangqianid].baodi - 1 }}次
      </div>
      <div class="baodi" v-else>这发必出</div>
      <div class="btn">
        <div @click="chouka(1)" id="mouseH"></div>
        <div @click="chouka(10)" id="mouseH"></div>
      </div>
      <div class="vid" v-show="vidflag">
        <div class="tg" @click="pausePlay()" id="mouseH">跳过></div>
        <video id="vid" muted autoplay="autoplay" loop="loop">
          <source src="../../../public/video/se.mp4" type="video/mp4" />
          您的浏览器不支持Video标签。
        </video>
      </div>
      <div class="tgcj" v-show="cancelflag" @click="jiesuan()" id="mouseH">
        x
      </div>
      <div class="tgcj" v-show="cancelflag2" @click="fanhui()" id="mouseH">
        x
      </div>
      <div id="mouseH" class="share" v-show="shareflag" @click="shares()">分享</div>
      <div id="ckmain" :class="{ cka: flag }">
        <div
          v-for="(v, i) in cklist"
          class="box"
          :key="i"
          @click="truebox()"
          v-show="boxflag == i"
        >
          <div class="pos">
            <div
              :style="{
                background: 'url(' + v.content + ')',
                'background-size': '100% 100%',
                'background-position': 'center center',
              }"
            ></div>
            <div>
              <div>{{ v.name }}</div>
              <div class="spos">
                <div
                  class="star sani"
                  v-for="(item, index) in v.star"
                  :key="index"
                ></div>
              </div>
            </div>
          </div>
          <div
            :style="{
              background: 'url(' + v.background + ')',
              'background-size': '150% 150%',
              'background-position': 'center center',
            }"
          ></div>
          <span
            :class="{
              zicol: v.star == 4,
              huangcol: v.star == 5,
              ckcol: v.star == 6,
            }"
          ></span>
        </div>
      </div>
      <div class="jiesuan" v-show="jiesuanflag" @click="fanhui()">
        <div class="jpos">
          <div class="endbox" v-for="(item, index) in cklist" :key="index">
            <div
              :class="{
                zicol2: item.star == 4,
                huangcol2: item.star == 5,
                ckcol2: item.star == 6,
              }"
            ></div>
            <div
              :style="{
                'background-image':
                  'linear-gradient(to bottom,transparent,#4b627906), url(' +
                  item.background +
                  ')',
                'background-size': '490% 120%',
                'background-position': 'center center',
              }"
              class="bg"
            >
              <div
                class="icon"
                :style="{
                  background: 'url(' + item.content + ')',
                  'background-size': '100% 100%',
                  'background-position': 'center center',
                }"
              ></div>
              <div class="spos">
                <div
                  class="star"
                  v-for="(item, index) in item.star"
                  :key="index"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="gailvtips">
      <div>
        <div>抽奖逻辑</div>
        <div>
          六星up池的up角色概率增加，但是里面不止一个六星，有可能出普通六星，如果出了普通六星则不刷新池子，仅作为刷新一次大保底的机会
        </div>
      </div>
      <div class="tip">
        <span>{{upnameliu}}(6星)</span><br /><span>{{upnamewu}}(5星)</span><br />概率UP!!!
      </div>
      <div class="gailv">
        <div>概率公示:</div>
        <span>6星{{ gailvliu }}%,up出现概率{{ upgailv * 10 }}%</span>&nbsp;
        <span>5星{{ gailvwu }}%,up出现概率{{ upgailv * 10 }}%</span><br />4星{{
          100 - (gailvliu + gailvwu)
        }}%
      </div>
    </div>
  </div>
</template>
<script>
import index from "./js/index.js";
export default index;
</script>
<style src="./css/index.css" scoped>
</style>