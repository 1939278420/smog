<template>
  <div>
    <el-menu
      mode="horizontal"
      :default-active="actives"
      :class="{ minmenu: flag }"
      id="mouseH"
    >
      <el-menu-item index="1" @click="selectH('/')" class="cursorElEmnuItem"
        >首页
      </el-menu-item>
      <el-submenu
        v-for="(submenus, index) in menus"
        :index="(index + 2).toString()"
        :key="index"
        id="mouseH"
      >
        <template slot="title">{{ submenus.title }}</template>
        <el-menu-item
          v-for="(item, subIndex) in submenus.menus"
          :index="(index + 2 + '-' + (subIndex + 1)).toString()"
          :key="item.key"
          class="cursorElEmnuItem"
          @click="selectH(item.link)"
          id="mouseH"
        >
          {{ item.title }}
        </el-menu-item>
      </el-submenu>
    </el-menu>
    <div
      class="xiala"
      @click="xiabtn()"
      v-show="$store.state.menuflagbtn"
      id="mouseH"
    >
      >
    </div>
  </div>
</template>
<script>
export default {
  watch: {
    "$store.state.pages"(value) {
      // console.log(value);
      if (value != 1) {
        this.actives = value + "-1";
      } else {
        this.actives = value;
      }
    },
  },
  data() {
    return {
      menus: [
        {
          title: "轮播图",
          menus: [{ title: "-极-", link: "/about" }],
        },
        {
          title: "工具组件",
          menus: [
            { title: "简历生成", link: "/Article" },
            { title: "Numbers", link: "/Number" },
            { title: "展示Tag", link: "/Tags" },
          ],
        },
        {
          title: "游戏组件",
          menus: [
            { title: "Genshin", link: "/genshin" },
            { title: "Pixel live", link: "/pix" },
          ],
        },
      ],
      actives: "1",
      flag: true,
    };
  },
  methods: {
    xiabtn() {
      this.flag = !this.flag;
      this.$store.commit("setflagbtn", false);
    },
    selectH(url) {
      this.$router.push(url);
    },
  },
  mounted() {
    this.$store.commit("setpages", 1);
    let scrollmenu = 0;
    let that = this;
    document.addEventListener("scroll", function () {
      if (scrollmenu < 150) {
        scrollmenu++;
      } else {
        scrollmenu = 0;
        that.flag = true;
        that.$store.commit("setflagbtn", true);
      }
    });
  },
};
</script>
<style lang="less" scoped>
.xiala {
  width: 40px;
  height: 40px;
  backdrop-filter: blur(25px);
  z-index: 99999;
  position: fixed;
  top: 10px;
  left: 10px;
  color: white;
  font-size: 40px;
  transform: rotate(90deg);
  text-align: center;
  line-height: 35px;
  border-radius: 5px;
  border: 2px solid salmon;
  transition: 0.3s ease;
  &:hover {
    transition: 0.3s ease;
    font-size: 45px;
    animation: fani 0.5s ease forwards;
    color: rgb(252, 90, 90);
  }
  @keyframes fani {
    0% {
      transform: rotate(90deg);
    }
    45% {
      transform: rotate(120deg);
    }
    100% {
      transform: rotate(90deg);
    }
  }
}
.minmenu {
  height: 0px !important;
  overflow: hidden;
}
/deep/ .el-submenu__title {
  width: auto;
  color: rgb(70, 70, 70) !important;
  // backdrop-filter: blur(5px);
  background-color: rgba(240, 248, 255, 0.363);
  font-size: 16px !important;
  cursor: url("../../static/images/xsdg.png") 3 3, default !important;
}
.cursorElEmnuItem {
  cursor: url("../../static/images/xsdg.png") 3 3, default !important;
}
::v-deep .el-menu {
  background: url(../../../public/img/title.png) !important;
  background-size: 100% 100%  !important;
  background-repeat: no-repeat !important;
  color: red !important;
}
/deep/ .el-menu-item.is-active:hover，.el-submenu .el-menu-item:hover {
  width: auto;
  cursor: url("../../static/images/xsdg.png") 3 3, default !important;
}
</style>