import Swiper from "swiper";
import 'swiper/css/swiper.css'
export default {
    name: "test2",
    data() {
        return {
            flag: false,
            i: 0,
            stxt: '',
            swiperList: [{
                img: "./img/p2t2/b1.png",
                text: '文字01'
            }, {
                img: "./img/p2t2/b2.png",
                text: '文字02'
            }, {
                img: "./img/p2t2/b3.png",
                text: '文字03'
            }, {
                img: "./img/p2t2/b4.png",
                text: '文字04'
            }, {
                img: "./img/swipers/t9.png",
                text: '文字05'
            }, ],
            timer: '',
            num: 0,
            tranX: 0,
            tranY: 0,
            tranZ: 50,
            rX: 0,
            rY: 0,
            tranXPro: 0,
            tranYPro: 0,
            hei: 937,
            wid: 1920
        };
    },
    mounted() {
        this.hei = window.innerHeight;
        this.wid = window.innerWidth;
        window.onresize = function() {
            that.hei = window.innerHeight;
            that.wid = window.innerWidth;
        };
        this.$store.commit('setpages', 2)
            // this.infine();
        this.stxt = this.swiperList[0].text
        this.swiper();
        var that = this
        document.addEventListener('mousemove', function(e) {
            var oEvent = e || window.event;
            // that.tranX = oEvent.clientX;
            // console.log(document.body.clientWidth);
            // console.log(document.body.clientHeight);
            setTimeout(() => {
                if (oEvent.clientX <= document.body.clientWidth / 2) {
                    that.tranX = ((oEvent.clientX - document.body.clientWidth / 2) / (25 / 2)).toFixed(2)
                } else {
                    that.tranX = ((oEvent.clientX - (document.body.clientWidth / 2)) / (25 / 2)).toFixed(2)
                }
                if (oEvent.clientY <= document.body.clientHeight / 2) {
                    that.tranY = (oEvent.clientY / 23.4 - 20).toFixed(2)
                } else {
                    that.tranY = ((oEvent.clientY - (document.body.clientHeight / 2)) / (23.4 / 2) / 2).toFixed(2)
                }
                let speed = 8.5
                that.rX = (that.tranX / speed).toFixed(2)
                that.rY = (that.tranY / speed).toFixed(2)
                that.tranXPro = (parseInt(that.tranX) * 1.6).toFixed(2)
                that.tranYPro = (parseInt(that.tranY) * 1.6).toFixed(2)
            }, 80);
            // that.tranY = oEvent.clientY;
            // that.tranZ = oEvent.clientX / 60;
        })
        var hiddenProperty = 'hidden' in document ? 'hidden' :
            'webkitHidden' in document ? 'webkitHidden' :
            'mozHidden' in document ? 'mozHidden' :
            null;
        var visibilityChangeEvent = hiddenProperty.replace(/hidden/i, 'visibilitychange');
        var onVisibilityChange = function() {
            if (!document[hiddenProperty]) {
                // console.log('页面激活');
                that.swiper()
            } else {
                clearInterval(that.timer)
                    // console.log('页面非激活')
            }
        }
        document.addEventListener(visibilityChangeEvent, onVisibilityChange);
    },
    methods: {
        addi(i) {
            clearInterval(this.timer)
                // console.log(this.num + i);
            if (this.num + i == this.swiperList.length) {
                this.num = 0
            } else if (this.num + i == -1) {
                this.num = this.swiperList.length - 1
            } else {
                this.num = this.num + i
            }
            this.i = this.num
            this.stxt = this.swiperList[this.i].text
            this.$nextTick(function() {
                setTimeout(() => {
                    this.swiper()
                }, 200);
            })
        },
        qiePage(index) {
            clearInterval(this.timer)
            this.i = index
            this.stxt = this.swiperList[this.i].text
            this.swiper()
        },
        swiper() {
            this.timer = setInterval(() => {
                if (this.num < this.swiperList.length - 1) {
                    this.num++
                } else {
                    this.num = 0
                }
                this.i = this.num
                this.stxt = this.swiperList[this.i].text
            }, 20000);
        },
        infine() {
            let mySwiper2 = new Swiper("#boxSwiper", {
                // autoplay: {
                //     delay: 3000,
                //     disableOnInteraction: false,
                //     pauseOnMouseEnter: true,
                //     reverseDirection: true,
                // },
                speed: 1200,
                loop: true,
                parallax: true,
                effect: "fade",
                // allowTouchMove: false,
                // direction: "vertical",
                // mousewheel: true,
                // forceToAxis: true,
                // autoHeight: true,
                // allowSlidePrev: false,
                // allowSlideNext: false, 关闭滑动
                // noSwiping: true,
                // slidesPerView: 1,
                preventInteractionOnTransition: true, //过渡时无法滑动
                paginationClickable: true,
            });
        },
    }
}