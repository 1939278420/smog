<template>
  <div class="box" :style="{'height':hei+'px','width':wid+'px'}">
    <!-- <div>{{tranX}}xx{{tranY}}xx{{tranZ}}xx{{rX}}xx{{rY}}</div> -->
    <!-- <div class="box1"> -->
    <div class="box1">
      <div
        class="bg"
        :style="{
          transform:
            'translate3d(' +
            tranX * 0.5 +
            'px,' +
            tranY * 0.5  +
            'px,' +
            tranZ +
            'px) rotateX(' +
            rX +
            'deg) rotateY(' +
            rY +
            'deg)',
        }"
      ></div>
      <div class="titles"
      :style="{
          transform:
            'translate3d(' +
            tranXPro +
            'px,' +
            tranYPro  +
            'px,' +
            tranZ +
            'px) rotateX(' +
            rX +
            'deg) rotateY(' +
            rY +
            'deg)',
        }"
      >
        {{stxt}}
      </div>
      <div class="ftitles"
      :style="{
          transform:
            'translate3d(' +
            tranXPro +
            'px,' +
            tranYPro  +
            'px,' +
            tranZ +
            'px) rotateX(' +
            rX +
            'deg) rotateY(' +
            rY +
            'deg)',
        }"
      >
        0{{i+1}}
      </div>
      <div class="xftitles"
      :style="{
          transform:
            'translate3d(' +
            tranXPro +
            'px,' +
            tranYPro  +
            'px,' +
            tranZ +
            'px) rotateX(' +
            rX +
            'deg) rotateY(' +
            rY +
            'deg)',
        }"
      >
        #Amazing
      </div>
      <ul class="gtitles"
      :style="{
          transform:
            'translate3d(' +
            tranXPro +
            'px,' +
            tranYPro  +
            'px,' +
            tranZ +
            'px)',
        }"
      >
        <li v-for="(v,index) in swiperList" :key="index" :class="{select:index==i}"></li>
      </ul>
      <div
        class="swiper tag"
        id="boxSwiper"
        :style="{
          transform:
            'translate3d(' +
            tranX * 1.3 +
            'px,' +
            tranY * 1.5 +
            'px,' +
            tranZ +
            'px) rotateX(' +
            rX +
            'deg) rotateY(' +
            rY +
            'deg)',
        }"
      >
        <div
          v-for="(item, index) in swiperList"
          :key="index"
          class="swiper-slide"
          :class="{'ani':index%2==0,'deani':index%2==1}"
          :style="{
            background: 'url(' + item.img + ')',
            'background-size': '100% 100%',
          }"
          v-show="index == i"
        ></div>
      </div>
      <div
        :style="{
          transform:
            'translate3d(' +
            tranX*1.2 +
            'px,' +
            tranY*1.2 +
            'px,' +
            tranZ +
            'px) rotateX(' +
            rX +
            'deg) rotateY(' +
            rY +
            'deg)',
        }"
      >
        <div class="prev">
          <el-button class="pre" @click="addi(-1)">&lt;</el-button>
          <el-button class="next" @click="addi(1)">&gt;</el-button>
        </div>
        <ul class="simg">
          <li
            v-for="(item, index) in swiperList"
            :key="index"
            :style="{
              background: 'url(' + item.img + ')',
              'background-size': '100% 100%',
            }"
            :class="{ sborder: index == i }"
            @click="qiePage(index)"
          ></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>
