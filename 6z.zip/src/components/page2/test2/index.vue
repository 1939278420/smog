<template>
  <div class="box">
    <div v-if="pages == $store.state.flag">
      <div class="pos">
        <div class="listImg" v-for="(v,i) in list" :key="i" :class="{'ani':i%2==0,'deani':i%2==1}" :style="{'background':'url('+v.imgsrc+')','background-size': 'cover'}">
          <div class="name opac nameani">{{v.title}}</div>
          <div class="fname opac fnameani">{{v.ftitle}}</div>
          <div class="title opac tani">{{v.tip}}</div>
          <!-- <img :class="{'ani':i%2==0,'deani':i%2==1}" :src="v.imgsrc" alt="" style="background-size: cover;background-position: center center"  /> -->
        </div>
      </div>
    </div>
     <div v-else>
      <div class="pos">
        <div class="listImg" v-for="(v,i) in list" :key="i" :style="{'background':'url('+v.imgsrc+')','background-size': 'cover'}">
          <div class="name">{{v.title}}</div>
          <div class="fname">{{v.ftitle}}</div>
          <div class="title">{{v.tip}}</div>
          <!-- <img :src="v.imgsrc" alt="" style="background-size: cover;background-position: center center" /> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>
