export default {
    name: "test2",
    data() {
        return {
            pages: 0,
            list: [{
                imgsrc: './img/p2t2/b1.png',
                title: '主要展示',
                ftitle: '01',
                tip: "FROM"
            }, {
                imgsrc: './img/p2t2/b2.png',
                title: '可随鼠标',
                ftitle: '02',
                tip: "HONKAI"
            }, {
                imgsrc: './img/p2t2/b3.png',
                title: '数据流图',
                ftitle: '03',
                tip: "STORE"
            }, {
                imgsrc: './img/p2t2/b4.png',
                title: '滚动图',
                ftitle: '04',
                tip: "SWIPER"
            }]
        };
    },

}