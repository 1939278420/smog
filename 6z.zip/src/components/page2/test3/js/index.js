export default {
    name: "test3",
    data() {
        return {
            pages: 2,
        };
    },
    mounted() {
        // setTimeout(() => {
        //     console.log(1);
        // }, 0);
        // new Promise(function aa(res) {
        //     console.log(2);
        //     for (var i = 0; i < 10000; i += 1) {
        //         i == 9999 && res()
        //     }
        //     console.log(3);
        // }).then(function() {
        //     console.log(4);
        // })
        // console.log(5);
    },
}