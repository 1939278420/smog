<template>
  <div class="box">
    <div class="pos opac" id="mains" ref="mains"></div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>
