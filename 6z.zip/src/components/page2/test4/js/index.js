import * as echarts from "echarts";
import 'echarts-gl';
import 'echarts/extension/bmap/bmap';
export default {
    name: "test3",
    data() {
        return {
            pages: 1,
            options: {
                title: {
                    text: '摸鱼情况预计',
                    subtext: '是真的哦',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                legend: {
                    data: ['摸鱼', '睡觉', '游戏热情'],
                    top: 30,
                    right: 10,
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [{
                    type: 'value'
                }],
                yAxis: [{
                    type: 'category',
                    axisTick: {
                        show: false
                    },
                    data: ['五月', '六月', '七月', '八月', '九月', '十月', '十一月']
                }],
                series: [{
                        name: '摸鱼',
                        type: 'bar',
                        label: {
                            show: true,
                            position: 'inside'
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [200, 170, 240, 244, 200, 220, 210]
                    },
                    {
                        name: '睡觉',
                        type: 'bar',
                        stack: 'Total',
                        label: {
                            show: true
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [320, 302, 341, 374, 390, 450, 420]
                    },
                    {
                        name: '游戏热情',
                        type: 'bar',
                        stack: 'Total',
                        label: {
                            show: true,
                            position: 'left'
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [-120, -132, -101, -134, -190, -230, -210]
                    }
                ]
            },
        };
    },
    mounted() {
        var charts = echarts.init(this.$refs.mains);
        charts.setOption(this.options);
    },
}