<template>
  <div class="box">
    <div class="bodys">
      <div class="main">
        <div
          class="btnpix"
          :style="{ 'background-color': '#' + item.color }"
          v-for="(item, index) in pixlist"
          :key="index"
          @click="changeCol(index)"
        ></div>
      </div>
      <div class="bottom">
        <div>
          <div class="pos">
            <span>请选择你的颜色:</span>
            <el-color-picker v-model="color1" id="mouseH"></el-color-picker>
          </div>
          <div class="colpos">
            <div
              class="btnpix"
              :style="{ 'background-color': item }"
              v-for="(item, index) in defualtCol"
              :key="index"
              @click="changebox(index)"
              id="mouseH"
            ></div>
          </div>
        </div>
        <div>
          <span>Tips:</span
          >选择合适的颜色点击方格即可,该操作会上传到数据库可供其他人发现并修改,游戏名为：像素大战
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>