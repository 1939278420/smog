export default {
    name: "pix",
    data() {
        return {
            color1: "#649",
            red: 'red',
            pixlist: [],
            defualtCol: ['#EE82EE', '#7B68EE', '#20B2AA', '#FF4500', '#8A2BE2', '#DA70D6'],
            btnflag: true
        };
    },
    mounted() {
        this.getPix()
    },
    methods: {
        async getPix() {
            const result = await this.$API.test4.getNewpix();
            this.pixlist = result
        },
        async changeCol(pid) {
            if (this.btnflag) {
                const col = this.color1.substring(1, this.color1.length)
                const result = await this.$API.test4.setpix(col, pid + 1);
                this.getPix()
                this.btnflag = false
                setTimeout(() => {
                    this.btnflag = true
                }, 500);
            } else {
                this.$message('请慢点~冷却中..');
            }
        },
        changebox(index) {
            this.color1 = this.defualtCol[index]
        }
    },
}