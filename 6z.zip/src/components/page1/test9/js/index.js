export default {
    name: "test4",
    data() {
        return {
            flag: 0
        };
    },
    mounted() {
        var that = this
        document.addEventListener('scroll', function() {
            // console.log(document.documentElement.scrollTop);
            if (document.documentElement.scrollTop >= 400 && document.documentElement.scrollTop <= 1099) {
                that.flag = 1
            } else if (document.documentElement.scrollTop >= 1100 && document.documentElement.scrollTop <= 1699) {
                that.flag = 2
            } else if (document.documentElement.scrollTop >= 1700) {
                that.flag = 3
            } else {
                that.flag = 0
            }
        })
    },
    methods: {
        goLive(i) {
            if (i == 1) {
                this.flag = 1
                document.documentElement.scrollTop = 400
            } else if (i == 2) {
                this.flag = 2
                document.documentElement.scrollTop = 1100
            } else if (i == 3) {
                this.flag = 3
                document.documentElement.scrollTop = 1700
            } else {
                this.flag = 0
                document.documentElement.scrollTop = 0
            }
        }
    }
}