<template>
  <div class="pos">
    <div class="dot">{{flag+1}}</div>
    <ul class="box">
      <li @click="goLive(i)" id='mouseH' v-for="(v,i) in 4" :key="i" :class="{'ani':flag==i,'deani':flag!=i}">
        {{i+1}}
      </li>
    </ul>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>