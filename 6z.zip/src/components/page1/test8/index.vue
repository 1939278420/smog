<template>
  <div class="pos" @mouseenter="bannerStop" @mouseleave="banner" id='mouseH'>
    <!-- <div class="title">我是标题a</div> -->
    <ul v-for="(v, i) in list" :key="i">
      <div v-if="i == flag" class="box" :class="{'animate':ani,'deani':!ani,}">
        <li v-for="(vs, i) in v" :key="i"><div>{{vs}}</div></li>
      </div>
    </ul>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>