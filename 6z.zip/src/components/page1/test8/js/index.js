export default {
    name: "test4",
    data() {
        return {
            flag: 0,
            list: [
                [
                    "不知道说什么所以水个字数",
                    "就是这样，很不错",
                    "我喜欢这个设计",
                    "字数上线还是要水",
                    "没问题这个功能",
                ],
                [
                    "兼容性很不错",
                    "作为文章的载体",
                    "路由的导向页面",
                    "可以说集成美观于一体",
                    "当然显示方面给阉割",
                ],
                [
                    "那是无可厚非的",
                    "美观和功能总是难以齐全",
                    "不过他好看啊",
                    "业务也没耽误",
                    "就是这样desu",
                ]
            ],
            ani: true,
            timer: '',
            timers: ''
        };
    },
    mounted() {
        this.banner()
    },
    methods: {
        banner() {
            this.timer = setInterval(() => {
                this.ani = false
                clearTimeout(this.timers)
                this.timers = setTimeout(() => {
                    this.ani = true
                    if (this.flag != this.list.length - 1) {
                        this.flag = this.flag + 1
                    } else {
                        this.flag = 0
                    }
                }, 1000);
            }, 6000);
        },
        bannerStop() {
            if (this.ani) {
                clearInterval(this.timer)
                clearTimeout(this.timers)
            }
        }
    }
}