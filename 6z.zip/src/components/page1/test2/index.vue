<template>
  <div>
    <div class="swiper tag" id="boxSwiper">
      <div class="swiper-wrapper">
        <div
          v-for="(item, index) in swiperList"
          :key="index"
          class="swiper-slide bg"
          :style="{
            background: 'url(' + item.img + ')',
            'background-size': '100% 100%',
          }"
        >
          <div
            class="title"
            data-swiper-parallax="-1300"
            data-swiper-parallax-duration="1200"
          >
            <p><svg t="1661325832448" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2345" width="200" height="200"><path d="M401.066667 512l302.933333 302.933333-59.733333 59.733334L341.333333 571.733333 281.6 512 341.333333 452.266667l302.933334-302.933334 59.733333 59.733334L401.066667 512z" fill="#ffffff" p-id="2346"></path></svg></p>
          </div>
           <div
            class="ftitle"
            data-swiper-parallax="1300"
            data-swiper-parallax-duration="1200"
          >
            <p><svg t="1661326183736" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3388" width="200" height="200"><path d="M761.055557 532.128047c0.512619-0.992555 1.343475-1.823411 1.792447-2.848649 8.800538-18.304636 5.919204-40.703346-9.664077-55.424808L399.935923 139.743798c-19.264507-18.208305-49.631179-17.344765-67.872168 1.888778-18.208305 19.264507-17.375729 49.631179 1.888778 67.872168l316.960409 299.839269L335.199677 813.631716c-19.071845 18.399247-19.648112 48.767639-1.247144 67.872168 9.407768 9.791372 21.984142 14.688778 34.560516 14.688778 12.000108 0 24.000215-4.479398 33.311652-13.439914l350.048434-337.375729c0.672598-0.672598 0.927187-1.599785 1.599785-2.303346 0.512619-0.479935 1.056202-0.832576 1.567101-1.343475C757.759656 538.879828 759.199462 535.391265 761.055557 532.128047z" p-id="3389" fill="#ffffff"></path></svg></p>
          </div>
        </div>
      </div>
      <!-- <div class="swiper-button-prev"></div>
      &lt;!&ndash;左箭头&ndash;&gt;
      <div class="swiper-button-next"></div>
      &lt;!&ndash;右箭头&ndash;&gt; -->
      <!-- <div class="swiper-dot"></div> -->
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style src="./css/index.css" scoped>
</style>
