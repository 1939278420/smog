import Swiper from "swiper";
import 'swiper/css/swiper.css'
export default {
    name: "test2",
    data() {
        return {
            swiperList: [{
                img: "./img/p2t2/b4.png",
            }, {
                img: "./img/p2t2/b2.png",
            }, {
                img: "./img/swipers/t2.png",
            }, {
                img: "./img/p2t2/b1.png",
            }, {
                img: "./img/swipers/t4.png",
            }, {
                img: "./img/swipers/t0.png",
            }, ],
        };
    },
    mounted() {
        this.infine();
    },
    methods: {
        infine() {
            let mySwiper2 = new Swiper("#boxSwiper", {
                autoplay: {
                    delay: 8000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true,
                    reverseDirection: true,
                },
                speed: 1200,
                loop: true,
                parallax: true,
                effect: "fade",
                // allowTouchMove: false,
                // direction: "vertical",
                // mousewheel: true,
                // forceToAxis: true,
                // autoHeight: true,
                // allowSlidePrev: false,
                // allowSlideNext: false, 关闭滑动
                // noSwiping: true,
                // slidesPerView: 1,
                preventInteractionOnTransition: true, //过渡时无法滑动
                paginationClickable: true,
            });
        },
    }
}