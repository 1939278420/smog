<template>
  <div class="pos">
    <div class="title">
      <div class="titles">TITLE</div>
      <div class="ftitles">{{num}}</div>
      {{ title }}
    </div>
    <div class="line ani posline">
      <div class="line sani"></div>
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>