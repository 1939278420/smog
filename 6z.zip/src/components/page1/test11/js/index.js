export default {
    name: "test11",
    data() {
        return {

        };
    },
    props: ['title', 'num'],
    created() {

    },
    methods: {

    }
}