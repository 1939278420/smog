<template>
  <div class="pos">
    <div>欢迎</div>
    <div>HONKAI的主站</div>
    <div>...........</div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>