<template>
  <div class="tagtips">
    <div>
      <div
        @click="selectTips(i)"
        class="tip"
        :class="{ tipselect: flag == i }"
        v-for="(v, i) in list"
        :key="i"
         id="mouseH"
      >
        <div class="xtip" v-if="flag == i" :class="{ xtipanis: flag == i }">
          -
        </div>
        <div class="xtip" v-else>+</div>
        <div class="mtip">{{ v.title }}</div>
        <div class="gtip">&gt;</div>
      </div>
    </div>
      <div class="conts">
        {{ list[flag].content }}
      </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>