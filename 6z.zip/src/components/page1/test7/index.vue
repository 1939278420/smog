<template>
  <div class="pos">
    <div class="box" v-for="(v,i) in count" :key="i" @click="artLink(i+1)" id="mouseH">{{i+1}}</div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>