export default {
    name: "test4",
    data() {
        return {
            count: 0
        };
    },
    mounted() {
        this.getAPI()
    },
    methods: {
        artLink(num) {
            var link = '/page/?num=' + parseInt(num)
            this.$router.push(link);
        },
        async getAPI() {
            const res = await this.$API.test2.getNewsCount();
            this.count = parseInt(res)
        },
    }
}