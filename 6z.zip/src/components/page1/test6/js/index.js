// import VueLazyload from "vue-lazyload";
// import Vue from 'vue'
// Vue.use(VueLazyload, {
//     preLoad: 1.3,
//     // error: require('../src/assets/image/error.png'),
//     // loading: require('../src/assets/image/loading.gif'),
//     attempt: 1
// })
export default {
    name: "test4",
    data() {
        return {
            list: ["./img/swipers/t1.png", "./img/p2t2/b2.png", "./img/swipers/t4.png", "./img/bs.png", "./img/swipers/t5.png", "./img/p2t2/b3.png"]
        };
    },
    mounted() {

    },
    methods: {

    }
}