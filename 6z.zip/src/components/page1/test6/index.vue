<template>
  <div>
    <div class="pos">
      <div v-for="(v, i) in list" :key="i" class="box">
        <img :src="v" alt="" srcset="" lazy />
      </div>
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>