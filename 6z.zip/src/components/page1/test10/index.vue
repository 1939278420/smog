<template>
  <div class="pos">
    <ul ref="tips">
    </ul>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>
<style lang="less">
.testTotip {
  color: white;
  text-shadow: 0px 5px 10px rgb(107, 107, 107);
  line-height: 50px;
  margin-top: 5px;
  overflow: hidden;
  background: url(../../../../public/img/ds3.png);
  background-size: 100% 100%;
  width: 100%;
  height: 50px;
  padding-left: 20px;
  font-size: 20px;
  font-weight: bold;
  position: relative;
  display: flex;
  justify-content: space-between;
  & > div:nth-child(2) {
    width: 50px;
    height: 50px;
    text-align: center;
    backdrop-filter: blur(25px);
    position: absolute;
    right: 25px;
    font-size: 30px;
    color: white;
    animation: anis 0.7s forwards ease;
    @keyframes anis {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
  }
}
.testAni {
    animation: enterani 0.7s forwards ease;
    @keyframes enterani {
      from {
        margin-left: 200px;
        padding-left: 100px;
      }
      to {
        margin-left: 0px;
        padding-left: 20px;
      }
    }
  }
  .testDeani {
    animation: xenterani 0.7s forwards ease;
    @keyframes xenterani {
      from {
        margin-left: 0px;
      }
      to {
        height: 0px;
        width: 0px;
        margin-left: 200px;
      }
    }
  }
</style>