export default {
    name: "test10",
    data() {
        return {
            list: [{
                    text: "唱",
                    tip: "!"
                },
                {
                    text: "跳",
                    tip: "?"
                },
                {
                    text: "rap",
                    tip: "X"
                },
                {
                    text: "篮球",
                    tip: "√"
                }, {
                    text: "music",
                    tip: "🐤"
                },
            ],
            timer: ''
        };
    },
    created() {
        setTimeout(() => {
            this.createTips()
        }, 200);
    },
    methods: {
        ctips(text, tip) {
            let lis = document.createElement('li');
            lis.classList.add('testTotip')
            lis.classList.add('testAni')
            lis.setAttribute("id", 'tip')
            lis.innerHTML = '<div>' + text + '</div><div>' + tip + '</div>';
            this.$refs.tips.appendChild(lis)
            this.desTips(lis)
        },
        createTips() {
            var num = 0
            this.timer = setInterval(() => {
                if (num < this.list.length) {
                    // let lis = document.createElement('li');
                    // lis.classList.add('testTotip')
                    // lis.classList.add('testAni')
                    // lis.setAttribute("id", 'tip')
                    // lis.innerHTML = '<div>' + this.list[num]['text'] + '</div><div>' + this.list[num]['tip'] + '</div>';
                    // this.$refs.tips.appendChild(lis)
                    // this.desTips(lis)
                    this.ctips(this.list[num]['text'], this.list[num]['tip'])
                    num++
                } else {
                    clearInterval(this.timer)
                }
            }, 1000);
        },
        desTips(lis) {
            let time = setTimeout(() => {
                lis.classList.remove('testAni')
                lis.classList.add('testDeani')
                setTimeout(() => {
                    this.$refs.tips.removeChild(lis)
                }, 1000);
            }, 3500);
        }
    }
}