import Swiper from "swiper";
import 'swiper/css/swiper.css'
import QRCode from "qrcode";
export default {
    name: "test4",
    data() {
        return {
            flag: false,
            index: 999,
            urlsImgQR: '',
            swiperList: [{
                img: "./img/swipers/t7.png",
            }, {
                img: "./img/swipers/t8.png",
            }, {
                img: "./img/swipers/t9.png",
            }, {
                img: "./img/swipers/t10.png",
            }, {
                img: "./img/swipers/t11.png",
            }, ],
            tagList: [{
                    title: "这是主站，欢迎来到网页端:cyberangel",
                    date: new Date().getFullYear() + "-" + new Date().getMonth() + "-" + new Date().getDay(),
                    status: "公告",
                },
                {
                    title: "还会继续优化，逐渐趋于完善",
                    date: new Date().getFullYear() + "-" + new Date().getMonth() + "-" + new Date().getDay(),
                    status: "新闻",
                },
                {
                    title: "就是这样，一个网站的搭建个人来说是费时费力的",
                    date: new Date().getFullYear() + "-" + new Date().getMonth() + "-" + new Date().getDay(),
                    status: "通知",
                }
            ]
        };
    },
    mounted() {
        this.infine();
        QRCode.toDataURL("https://space.bilibili.com/34103946")
            .then((url) => {
                this.urlsImgQR = url;
            })
            .catch((err) => {
                console.error(err);
            });
    },
    methods: {
        infine() {
            let mySwiper3 = new Swiper("#TipsSwiper", {
                autoplay: {
                    delay: 3000,
                    pauseOnMouseEnter: true,
                },
                speed: 1200,
                loop: true,
                effect: "fade",
                pagination: {
                    el: '.dots',
                },
            });
        },
        lisHover(i) {
            this.index = i
            this.flag = true
        },
        lisLeav(i) {
            this.index = i
            this.flag = false
        },
        QRMsg() {

        }
    }
}