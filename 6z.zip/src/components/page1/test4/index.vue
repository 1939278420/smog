<template>
  <div class="tagtips">
    <div class="Llag">
      <div class="swiper tag" id="TipsSwiper">
        <div class="swiper-wrapper">
          <div
            v-for="(item, index) in swiperList"
            :key="index"
            class="swiper-slide"
            :style="{
              background: 'url(' + item.img + ')',
              'background-size': 'cover',
              'background-position': 'center',
            }"
          ></div>
        </div>
        <div class="swiper-pagination dots" id="dots"></div>
      </div>
      <div class="list">
        <ul>
          <ol v-for="(v, i) in tagList" :key="i" class="lis" id="mouseH">
            <div class="tips">
              <span>READ MORE +</span>
            </div>
            <div class="date">{{ v.date }}</div>
            <div class="status">{{ v.status }}</div>
            <div class="title">{{ v.title }}</div>
          </ol>
        </ul>
      </div>
    </div>
    <div class="Rlag qr">
        <img class="imgQR" :src="urlsImgQR"/>
        <img class="imgQR" src="../../../../public/img/sx.jpg"/>
        <img class="imgQR" src="../../../../public/img/sd.jpg"/>
    </div>
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>