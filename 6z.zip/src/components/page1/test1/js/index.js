export default {
    name: "test1",
    data() {
        return {
            list: [{
                    isNew: false,
                    title: "主站",
                    ftitle: "never",
                    url: "https://www.bilibili.com/video/BV1GJ411x7h7?share_source=copy_web&spm_id_from=444.41.0.0&vd_source=9e766831e11c35f655c207e7ecbacb51",
                    img: "./img/p2t2/b4.png",
                    color: "#6495ED"
                },
                {
                    isNew: false,
                    title: "雾霾空间",
                    ftitle: "早期js",
                    url: "http://honkai.store/smogs",
                    img: "./img/p2t2/b3.png",
                    color: "#DCDCDC"
                },
                {
                    isNew: false,
                    title: "山东技校网页(仿随机学校)",
                    ftitle: "纯H5+JQ网页",
                    url: "http://honkai.store/test1/",
                    img: "./img/s2.png",
                    color: "#FF4500"
                },
                {
                    isNew: false,
                    title: "手机端",
                    ftitle: "手机端访问",
                    url: "http://honkai.store/phone/",
                    img: "./img/s3.png",
                    color: "#7B68EE"
                },
                {
                    isNew: true,
                    title: "全端兼容的祝贺",
                    ftitle: "Happy Brithday",
                    url: "http://honkai.store/birthday/#/",
                    img: "./img/s4.png",
                    color: "#4169E1"
                },
                {
                    isNew: true,
                    title: "评论区",
                    ftitle: "是集成量很高的家伙",
                    url: "http://honkai.store/birthday/#/comment",
                    img: "./img/s5.png",
                    color: "#FFD700"
                },
            ],
        };
    },
    methods: {
        locato(u) {
            location.href = u
        }
    }
}