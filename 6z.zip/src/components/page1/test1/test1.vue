<template>
  <div class="boxs">
    <div
     id="mouseH"
      class="btnbox"
      v-for="(v, i) in list"
      :key="i"
      @click="locato(v.url)"
      :style="{
        'background': 'url('+v.img+')',
        'background-size': 'cover',
        'background-position': 'center',
        'background-repeat':'no-repeat',
        'border-top': '5px solid'+v.color+''
        }
      "
    >
      <div class="tag" v-show="v.isNew">NEW</div>
      <div class="bottom">
        <div>
          <div>
            {{ v.title }}
          </div>
          <div>{{ v.ftitle }}</div>
        </div>
        <!-- <div><el-button class="btn" size="default" @click.stop="locato(v.url)">GO</el-button></div> -->
      </div>
    </div>
  </div>
</template>

<script>
import index from './js/index'
export default index
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">

</style>
