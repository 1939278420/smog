export default {
    name: "test13",
    data() {
        return {
            list: ['2', '0', '2', '3']
        };
    },
    created() {

    },
    methods: {

    }
}