<template>
  <div class="qr">
    <img class="imgQR" :src="urlsImgQR" />
    <img class="imgQR" src="../../../../public/img/sx.jpg" />
    <img class="imgQR" src="../../../../public/img/sd.jpg" />
  </div>
</template>

<script>
import index from "./js/index";
export default index;
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./css/index.css">
</style>
