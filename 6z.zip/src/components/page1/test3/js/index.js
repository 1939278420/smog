import QRCode from "qrcode";
export default {
    name: "test3",
    data() {
        return {
            urlsImgQR: '',
        };
    },
    mounted() {
        QRCode.toDataURL("https://space.bilibili.com/34103946")
            .then((url) => {
                this.urlsImgQR = url;
            })
            .catch((err) => {
                console.error(err);
            });
    },
    methods: {

    }
}