<template>
  <div class="hoverme" id="mouseH">
    <div
      class="backtop"
      @click="comeback"
      :class="{ deani: aniflag }"
      v-show="flag"
    >
      <svg
        t="1661327179939"
        class="icon"
        viewBox="0 0 1024 1024"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
        p-id="1375"
        width="200"
        height="200"
      >
        <path
          d="M854.016 739.328l-313.344-309.248-313.344 309.248q-14.336 14.336-32.768 21.504t-37.376 7.168-36.864-7.168-32.256-21.504q-29.696-28.672-29.696-68.608t29.696-68.608l376.832-373.76q14.336-14.336 34.304-22.528t40.448-9.216 39.424 5.12 31.232 20.48l382.976 379.904q28.672 28.672 28.672 68.608t-28.672 68.608q-14.336 14.336-32.768 21.504t-37.376 7.168-36.864-7.168-32.256-21.504z"
          p-id="1376"
          fill="#1296db"
        ></path>
      </svg>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      flag: false,
      aniflag: false,
    };
  },
  methods: {
    comeback() {
      let timer;
      let num = 0;
      timer = setInterval(() => {
        if (num < 50) {
          document.documentElement.scrollTop -= 15;
          num += 1;
        } else {
          clearInterval(timer);
          document.documentElement.scrollTop = 0;
        }
      }, 1);
    },
  },
  mounted() {
    this.$nextTick(function(){
      this.comeback();
    })
    let that = this;
    document.addEventListener("scroll", (e) => {
      if (document.documentElement.scrollTop > 500) {
        if (!that.flag) {
          that.flag = true;
          that.aniflag = false;
        }
      } else {
        if (that.flag) {
          that.aniflag = true;
          that.flag = false;
        }
      }
    });
  },
};
</script>
<style lang="less" scoped>
.hoverme {
  &:hover {
    transition: .3s ease;
    .backtop {
      animation: anis 0.7s ease infinite;
    }
  }
    width: 80px;
    height:80px;
  position: fixed;
  right: 65px;
  bottom: 50px;
}
.backtop {
  position: absolute;
  & > svg {
    width: 50px;
    height: 50px;
    animation: ani 0.3s ease forwards;
  }
  @keyframes anis {
    0% {
      bottom: 40px;
    }
    50% {
      bottom: 50px;
    }
    100% {
      bottom: 40px;
    }
  }
  display: flex;
  justify-content: center;
  align-items: center;
  left:17% ;
  top:20% ;
  @keyframes ani {
    from {
      width: 20px;
      height: 20px;
    }
    to {
      width: 50px;
      height: 50px;
    }
  }
}
</style>