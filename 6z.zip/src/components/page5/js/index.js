import ElementUI from 'element-ui';
export default {
    data() {
        return {
            simg: './img/sad.jpeg',
            xinput: '',
            list: [],
            qlist: [],
            flag: 3,
            status: true,
            addTagFlag: true,
            AddTagtitle: "",
            AddTagicon: "",
            AddTagcontent: "",
            iconTag: ["./img/sad.jpeg", "https://s1.ax1x.com/2022/11/11/zCYKX9.jpg", "https://s1.ax1x.com/2022/11/11/zCYl01.jpg", "https://s1.ax1x.com/2022/11/11/zCY1Tx.jpg"],
            iconflag: 0,
            addmainFlag: 2
        }
    },
    watch: {
        xinput(newV, Oldv) {
            this.qlist = []
            if (newV != "") {
                this.list.forEach(element => {
                    if ((element.title).indexOf(newV.toLowerCase()) != -1 ||
                        (element.content).indexOf(newV.toLowerCase()) != -1 ||
                        (element.title).indexOf(newV.toUpperCase()) != -1 ||
                        (element.content).indexOf(newV.toUpperCase()) != -1) {
                        this.qlist.push(element)
                    }
                });
                if (this.qlist.length == 0 && this.flag != 3) {
                    this.flag = 1
                }
                if (this.qlist.length > 0) {
                    this.flag = 2
                }
            } else if (this.flag != 3) {
                this.flag = 1
            }
        }
    },
    mounted() {
        this.getApi()
    },
    methods: {
        async getApi() {
            const result = await this.$API.test3.getAllTag()
            this.list = result;
        },
        qid(id) {
            // this.$router.push('page/?num=' + id)
            this.$message('暂时不能跳转,功能未开放！');
        },
        descList() {
            let list = []
            let num = this.list.length - 1;
            this.list.forEach(element => {
                list[num] = element
                num--
            })
            this.list = list;
            this.status = !this.status
        },
        ascList() {
            let list = []
            let num = 0;
            this.list.forEach(element => {
                list[num] = element
                num++
            })
            this.list = list;
            this.status = !this.status
        },
        addTag() {
            if (this.addTagFlag) {
                this.addTagFlag = false
                if (this.addmainFlag != 1) {
                    this.addmainFlag = 1
                } else {
                    this.addmainFlag = false
                }
                setTimeout(() => {
                    this.addTagFlag = true
                }, 3000);
            } else {
                alert('冷却中..')
            }
        },
        setIcon(i) {
            this.iconflag = i
            this.AddTagicon = this.iconTag[i]
        },
        async FinalAddTag() {
            const result = await this.$API.test3.setNewTag(this.AddTagtitle, this.AddTagcontent, this.AddTagicon)
            this.getApi()
            this.AddTagcontent = ""
            this.AddTagicon = 0
            this.AddTagtitle = ""
        }
    }
}