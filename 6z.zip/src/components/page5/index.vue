<template>
  <div class="page">
    <div class="addMain" :class="{'find':addmainFlag==1,'hid':!addmainFlag==1}">
      <div class="backAdd" @click="addmainFlag=false" id="mouseH">&lt;</div>
      <div class="addtag">
        <div>标题:</div>
        <el-input
          maxlength="13"
          minlength="1"
          :show-word-limit="true"
          :clearable="true"
          v-model="AddTagtitle"
          placeholder="请输入内容"
          autocomplete="on"
          class="ipt"
        ></el-input>
      </div>
      <div class="addtag">
        <div>内容:</div>
        <el-input
          maxlength="35"
          minlength="1"
          :show-word-limit="true"
          :clearable="true"
          v-model="AddTagcontent"
          placeholder="请输入内容"
          autocomplete="on"
          class="ipt"
        ></el-input>
      </div>
      <ul class="tagicon">
        <li v-for="(v,i) in iconTag" :key="i" @click="setIcon(i)">
          <img :src="v" alt="" srcset="" :class="{'bord':iconflag==i}">
        </li>
      </ul>
      <el-button id="mouseH" class="ebtn" type="primary" size="default" @click="FinalAddTag()">选好了</el-button>
    </div>
    <div class="TagDefault">
      <div class="pos">
        <div class="desc">
          <div @click="descList()" v-if="status" id="mouseH">以发布时间降序</div>
          <div @click="descList()" id="mouseH" v-else>以发布时间升序</div>
        </div>
        <div class="desc">
          <div @click="addTag()" id="mouseH">添加Tag</div>
        </div>
      </div>
      <el-input
        maxlength="5"
        minlength="1"
        :show-word-limit="true"
        :clearable="true"
        class="search"
        v-model="xinput"
        placeholder="请输入内容"
        autocomplete="on"
      ></el-input>
      <div class="TagsBox">
        <div
          class="sTagbox Tagbox"
          v-for="(v, i) in list"
          :key="i"
          @click="qid(v.id)"
        >
          <div class="icon"><img :src="v.icon" alt="" /></div>
          <div class="content">
            <div>{{ v.title }}</div>
            <div>{{ v.content }}</div>
          </div>
          <div class="cetiao">></div>
        </div>
      </div>
    </div>
    <div class="Tags" :class="{ shouqi: flag == 1, zhankai: flag == 2 }">
      <div class="Tagbox" v-for="(v, i) in qlist" :key="i" @click="qid(v.id)">
        <div class="icon"><img :src="v.icon" alt="" /></div>
        <div class="content">
          <div>{{ v.title }}</div>
          <div>{{ v.content }}</div>
        </div>
        <div class="cetiao">></div>
      </div>
    </div>
  </div>
</template>
<script>
import index from "./js/index.js";
export default index;
</script>
<style src="./css/index.css" scoped>
</style>