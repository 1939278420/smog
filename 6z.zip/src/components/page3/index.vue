<template>
  <div>
    <div class="fons">{{ num }}</div>
    <div class="compont">
      <el-input
        v-model="unum"
        placeholder="输入数字"
        size="normal"
        clearable
      ></el-input>
      <el-button type="primary" size="default" @click="aclick">提交</el-button>
    </div>
  </div>
</template>
<script>
import index from "./js/index.js";
export default index;
</script>
<style src="./css/index.css" scoped>
</style>