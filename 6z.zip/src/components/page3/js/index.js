export default {
    data() {
        return {
            num: 300,
            unum: '',
            timer: '',
            flag: true
        }
    },
    methods: {
        aclick() {
            if (this.flag) {
                this.flag = !this.flag
                this.fdou()
            } else {
                const h = this.$createElement;
                this.$message({
                    message: h('p', null, [
                        h('span', null, '上一轮还没运行完!'),
                        h('i', { style: 'color: teal' }, '[警告]')
                    ])
                });
            }
        },
        fdou() {
            this.unum = parseInt(this.unum)
            clearInterval(this.timer)
            let nums = this.unum - this.num
            this.timer = setInterval(() => {
                if (this.unum > this.num) {
                    if (nums > 200 && parseFloat(this.unum - this.num) < nums * 0.9) {
                        this.num = parseInt(this.unum)
                    } else { this.num += 1 }
                } else if (this.unum < this.num) {
                    if (nums < -200 && (this.unum - this.num) < nums * 0.9) {
                        this.num -= 1
                    } else { this.num = parseInt(this.unum) }
                } else {
                    clearInterval(this.timer)
                    this.flag = true
                }
            }, 10);
        }
    },
}