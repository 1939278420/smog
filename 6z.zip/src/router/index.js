import Vue from 'vue';
import VueRouter from 'vue-router';
import HomeView from '../views/HomeView/HomeView.vue';
import Article from '../views/Article/Article.vue'
import Number from '../components/page3'
import page from '../components/page4'
import Tags from '../components/page5'

Vue.use(VueRouter);

const routes = [{
        path: '/',
        name: '',
        component: HomeView,
        children: [{
            path: '/',
            name: '',
            component: () =>
                import ('../views/HomeView/index/index.vue'),
        }, {
            path: '/page/:num?',
            name: 'page',
            component: page
        }, {
            path: '/theme',
            name: 'theme',
            component: () =>
                import ( /* webpackChunkName: "about" */ '../components/theme'),
        }]
    },
    {
        path: '/about',
        name: 'about',
        component: () =>
            import ( /* webpackChunkName: "about" */ '../views/SwiperView.vue'),
    },
    {
        path: '/Article',
        name: 'Article',
        component: Article,
    },
    {
        path: '/Number',
        name: 'Number',
        component: Number,
    },
    {
        path: '/Tags',
        name: 'Tags',
        component: Tags,
    },
    {
        path: '/pix',
        name: 'pix',
        component: () =>
            import ( /* webpackChunkName: "about" */ '../components/pixol'),
    },
    {
        path: '/genshin',
        name: 'genshin',
        component: () =>
            import ( /* webpackChunkName: "about" */ '../components/genshin'),
    }
];

const router = new VueRouter({
    // mode: 'history',
    // base: process.env.BASE_URL,
    routes,
});
router.beforeEach((to, from, next) => {
    // console.log(to, from);
    document.documentElement.scrollTop = 0
    next()
})
router.afterEach((to, from) => {

})
const routerRePush = VueRouter.prototype.push
VueRouter.prototype.push = function(location) {
    return routerRePush.call(this, location).catch(error => error)
}

export default router;